uvicorn src.main:app --reload
python src/demo.py
python src/sync_models.py
1、https://github.com/portkey-ai/gateway是 Portkey AI Gateway 的开源仓库，核心是为生成式 AI 应用提供一个高性能、统一的大语言模型（LLM）网关层，解决生产环境中集成多类 LLM 的可靠性、性能和扩展性问题。
2、python src/sync_models.py
